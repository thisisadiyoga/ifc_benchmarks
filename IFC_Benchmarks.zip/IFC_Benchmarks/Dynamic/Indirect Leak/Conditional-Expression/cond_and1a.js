// Conditional Expression: AND
// Leak

document.cookie = 'abc';
var a = document.cookie;
var b = (true && a == 'abc') ? 2 : 1;
document.cookie = b;