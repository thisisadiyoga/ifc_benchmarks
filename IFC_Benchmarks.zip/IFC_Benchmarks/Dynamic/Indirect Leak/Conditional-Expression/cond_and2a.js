// Conditional Expression: AND
// NO Leak

document.cookie = 'abc';
var a = document.cookie;
var b = (false && a == 'abc') ? 2 : 1;
document.cookie = b;