// Undefined Renaming
// NO Leak

function undef() { return; }
var undefined = 2;
console.log(undef() == undefined);	// false