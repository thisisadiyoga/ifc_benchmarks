// Undefined Renaming
// ERROR

function foo() {
  var undefined = 2;
  return z + 2;
}
console.log(foo());