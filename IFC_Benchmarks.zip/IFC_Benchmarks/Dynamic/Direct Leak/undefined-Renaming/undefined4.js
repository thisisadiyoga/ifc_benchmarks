// Undefined Renaming
// NO Leak

function undef() { return; }
var undefined = document.cookie;
document.cookie = undef();	// An incorrect representation of undefined will return information flow error