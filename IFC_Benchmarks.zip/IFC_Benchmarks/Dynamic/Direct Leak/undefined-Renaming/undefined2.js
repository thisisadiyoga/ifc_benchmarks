// Undefined Renaming
// NO Leak

function undef() { return undefined; }
var undefined = 2;
console.log(undef() == undefined);	// true