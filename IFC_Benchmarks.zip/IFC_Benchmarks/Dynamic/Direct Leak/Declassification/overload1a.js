// Declassification: Overload
// Leak

function encodeURI(input) {
	return input;
}

document.cookie = 'abc';
var a = document.cookie;
var b = encodeURI(a);
document.cookie = b;
console.log(document.cookie);
// print abc