// Declassification: Reclassification
// Leak

document.cookie = 'abc';
var a = document.cookie;
var b = encodeURI(a);
b = decodeURI(b);
document.cookie = b;
console.log(document.cookie);
// print abc