// Declassification: Overload
// NO Leak

var encode = encodeURI;
encodeURI = function (input) {
	return encode(input);
}

document.cookie = 'abc';
var a = document.cookie;
var b = encodeURI(a);
document.cookie = b;
console.log(document.cookie);
encodeURI = encode;
// print abc