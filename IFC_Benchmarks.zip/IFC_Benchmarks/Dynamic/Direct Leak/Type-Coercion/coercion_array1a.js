// Type Coercion: Array -> String
// Leak

document.cookie = 'abc';
var arr = [];
arr[0] = document.cookie[0];
arr[1] = document.cookie[1];
arr[2] = document.cookie[2];
document.cookie = arr;
console.log(document.cookie);