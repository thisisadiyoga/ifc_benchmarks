// Type Coercion: Object
// NO Leak

document.cookie = 'abc';
var x = {toString: function() { return document.cookie; }, valueOf: function() { return 1; }};
document.cookie = x + 'cde';
console.log(document.cookie);