// Type Coercion: toString
// Leak

document.cookie = 'abc';
var x = {toString: function() { return document.cookie; }};
document.cookie = x + 'cde';