// Type Coercion: valueOf
// Leak

document.cookie = 'abc';
var x = {valueOf: function() { return document.cookie; }};
document.cookie = x + 'cde';