// Type Coercion: Number -> String
// Leak

document.cookie = '1';
var a = document.cookie * 2;
document.cookie = a;
console.log(document.cookie);