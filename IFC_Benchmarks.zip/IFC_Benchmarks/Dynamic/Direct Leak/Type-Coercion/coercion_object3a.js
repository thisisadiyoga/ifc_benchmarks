// Type Coercion: Object
// ERROR

document.cookie = 'abc';
var c = 0;
var x = {toString: function() { c++; return {toString: function() { return document.cookie; }}}, valueOf: function() { c++; return {toString: function() { return document.cookie; }}} };
document.cookie = x + 'cde';
console.log(document.cookie);
console.log(c);