// Type Coercion: Object
// NO Leak

document.cookie = 'abc';
var c = 0;
var x = {toString: function() { return 1; }, valueOf: function() { c++; return {toString: function() { return document.cookie; }}; }};
document.cookie = x + 'cde';
console.log(document.cookie);
console.log(c);