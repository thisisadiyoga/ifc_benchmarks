// Type Coercion: Object
// Leak

document.cookie = 'abc';
var x = {toString: function() { return 1; }, valueOf: function() { return document.cookie; }};
document.cookie = x + 'cde';
console.log(document.cookie);