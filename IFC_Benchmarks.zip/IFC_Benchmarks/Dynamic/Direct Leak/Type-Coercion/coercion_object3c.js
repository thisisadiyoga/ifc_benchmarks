// Type Coercion: Object
// NO Leak

document.cookie = 'abc';
var c = 0;
var x = {toString: function() { c++; return {toString: function() { return document.cookie; }}}, valueOf: function() { c++; return {toString: function() { return document.cookie; }}} };
try {
	document.cookie = 'cde' + x;
} catch(e) {}
console.log(document.cookie);
console.log(c);