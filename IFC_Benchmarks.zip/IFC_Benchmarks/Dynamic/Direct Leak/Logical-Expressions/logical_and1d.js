// Logical: AND
// Leak

document.cookie = 'abc';
var a = document.cookie;
var b = true && a !== 'abc';
document.cookie = b;