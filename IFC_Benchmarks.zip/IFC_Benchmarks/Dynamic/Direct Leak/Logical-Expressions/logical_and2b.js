// Logical: AND
// NO Leak

document.cookie = 'abc';
var a = document.cookie;
var b = false && a != 'abc';
document.cookie = b;