// Logical: NOT
// Leak

document.cookie = 'abc';
var a = document.cookie;
var b = !(a == 'abc');
document.cookie = b;