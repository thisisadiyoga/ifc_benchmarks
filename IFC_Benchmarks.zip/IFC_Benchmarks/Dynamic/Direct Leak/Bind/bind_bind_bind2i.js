// Bind: Bind.Bind(Bind, Lib)
// Leak

document.cookie = 'abc';
var a = document.cookie;
var b = Function.prototype.bind.bind(Function.prototype.bind, String.prototype.substring, a);
var c = b();
var d = c(0, 1);
document.cookie = d();
console.log(document.cookie);