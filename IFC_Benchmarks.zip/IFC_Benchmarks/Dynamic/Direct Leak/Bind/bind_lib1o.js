// Bind: Lib.Bind
// NO Leak

document.cookie = 'cde';
var a = document.cookie;
var f = String.prototype.substring.bind('a', 0);
var b = f(1, a.length);
document.cookie = b;
console.log(document.cookie);