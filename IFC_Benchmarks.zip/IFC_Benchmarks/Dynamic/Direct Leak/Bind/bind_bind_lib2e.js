// Bind: Bind.Bind(Lib)
// Leak

document.cookie = 'abc';
var c = document.cookie;
var a = Function.prototype.bind.bind(String.prototype.substring);
var b = a('abc', 0, c.length);
document.cookie = b();
console.log(document.cookie);