// Bind: Normal.Bind
// NO Leak

function foo(x, y) {
	document.cookie = this.v;
  console.log(this.v + " " + x + " " + y);
}

var a = foo.bind({v: 5}, 1, 2);
var b = a.bind({});
var c = b.bind({});
c();