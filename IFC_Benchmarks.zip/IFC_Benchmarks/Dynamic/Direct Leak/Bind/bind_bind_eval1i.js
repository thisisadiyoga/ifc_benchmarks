// Bind: Bind.Bind(Eval)
// NO Leak

var a1 = "document.cookie = 'abc'; var d = document.cookie; document.cookie = d; console.log(d);";
var a2 = "document.cookie = 'abc'; var d = 'cde'; document.cookie = d; console.log(d);";
var b  = Function.prototype.bind.bind(eval, {});
var c  = b(a2);
c(a1);