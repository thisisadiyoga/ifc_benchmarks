// Bind: Bind.Bind(Bind, Lib)
// NO Leak

document.cookie = 'abc';
var a = document.cookie;
var b = Function.prototype.bind.bind(Function.prototype.bind, String.prototype.substring, 'abc');
var c = b(0);
var d = c(1, a.length);
document.cookie = d();
console.log(document.cookie);