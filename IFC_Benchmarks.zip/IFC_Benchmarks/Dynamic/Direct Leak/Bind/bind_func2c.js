// Bind: Normal.Bind
// Leak

function foo(x, y) {
	document.cookie = this.v;
  console.log(this.v + " " + x + " " + y);
}

var a = foo.bind({v: document.cookie}, 1);
var b = a.bind({});
var c = b.bind({}, 2);
c();