// Bind: Bind.Bind(Lib)
// Leak

document.cookie = 'abc';
var a = Function.prototype.bind.bind(String.prototype.substring);
var b = a(document.cookie, 0, 1);
document.cookie = b();
console.log(document.cookie);