// Bind: Normal.Bind
// Leak

function foo(x, y) {
	document.cookie = x + y;
  console.log(this.v + " " + x + " " + y);
}
document.cookie = 'abc';
var d = document.cookie;
var a = foo.bind({v: 5});
var b = a.bind({v: 4}, d);
var c = b.bind({v: 3}, 2);
c();