// Bind: Eval.Bind
// Leak

a = document.cookie;	// force a to be global
var f = eval.bind({});
f('document.cookie = a;');