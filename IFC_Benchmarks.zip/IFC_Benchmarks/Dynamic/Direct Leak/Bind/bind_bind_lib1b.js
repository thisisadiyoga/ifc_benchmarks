// Bind: Bind.Bind(Lib)
// Leak

document.cookie = 'abc';
var a = Function.prototype.bind.bind(String.prototype.substring, document.cookie);
var b = a();
document.cookie = b(0, 1);
console.log(document.cookie);