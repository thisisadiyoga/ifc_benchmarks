// Bind: Normal.Bind
// Leak

function foo(x, y) {
	document.cookie = x + y;
  console.log(this.v + " " + x + " " + y);
}
document.cookie = 'abc';
var d = document.cookie;
var a = foo.bind({v: 5}, d);
var b = a.bind({v: 4}, 1);
var c = b.bind({v: 3}, 2);
c();