// Bind: Bind.Bind(Lib)
// Leak

document.cookie = 'abc';
var a = Function.prototype.bind.bind(String.prototype.substring, document.cookie, 0);
var b = a();
document.cookie = b(1);
console.log(document.cookie);