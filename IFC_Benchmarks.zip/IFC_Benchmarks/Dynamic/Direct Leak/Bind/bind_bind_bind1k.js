// Bind: Bind.Bind(Bind)
// Leak

var a = "document.cookie = 'abc'; var d = document.cookie; document.cookie = d; console.log(d);";
var b = Function.prototype.bind.bind(Function.prototype.bind);
var c = b(eval, {}, a);
var d = c();
d();