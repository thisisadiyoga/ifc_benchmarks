// Bind: Bind.Bind(Lib)
// Leak

document.cookie = 'abc';
var a = Function.prototype.bind.bind(String.prototype.substring, document.cookie, 0, 1);
var b = a();
document.cookie = b();
console.log(document.cookie);