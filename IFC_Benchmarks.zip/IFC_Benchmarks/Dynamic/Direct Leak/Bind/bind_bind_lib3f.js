// Bind: Bind.Bind(Lib)
// NO Leak

document.cookie = 'abc';
var c = document.cookie;
var a = Function.prototype.bind.bind(String.prototype.substring, 'abc', 0);
var b = a(1, c.length);
document.cookie = b(c.length);
console.log(document.cookie);