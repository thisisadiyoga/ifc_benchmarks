// Bind: Lib.Bind
// Leak

var a = document.cookie;
var f = String.prototype.substring.bind('a', 0);
var b = f(a.length);
document.cookie = b;