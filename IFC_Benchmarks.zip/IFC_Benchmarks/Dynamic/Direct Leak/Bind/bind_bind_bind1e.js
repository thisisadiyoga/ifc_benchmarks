// Bind: Bind.Bind(Bind)
// Leak

var a = "document.cookie = 'abc'; var d = document.cookie; document.cookie = d; console.log(d);";
var b = Function.prototype.bind.bind(Function.prototype.bind, eval, {});
var c = b();
var d = c();
d(a);