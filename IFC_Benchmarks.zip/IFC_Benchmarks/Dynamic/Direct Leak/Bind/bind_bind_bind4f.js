// Bind: Bind.Bind(Bind, Lib)
// Leak

document.cookie = 'abc';
var a = document.cookie;
var b = Function.prototype.bind.bind(Function.prototype.bind, String.prototype.substring, 'abc');
var c = b(0);
var d = c();
document.cookie = d(a.length);
console.log(document.cookie);