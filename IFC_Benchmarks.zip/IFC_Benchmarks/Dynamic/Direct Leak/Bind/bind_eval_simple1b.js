// Bind: Eval.Bind
// Leak

var f = eval.bind({}, 'var a = document.cookie; document.cookie = a;');
f();