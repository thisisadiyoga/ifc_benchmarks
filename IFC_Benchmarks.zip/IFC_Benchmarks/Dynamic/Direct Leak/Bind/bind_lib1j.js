// Bind: Lib.Bind
// Leak

var a = document.cookie;
var f = String.prototype.substring.bind(a, 0, a.length);
var b = f();
document.cookie = b;