// Bind: Lib.Bind
// Leak

var a = document.cookie;
var f = String.prototype.substring.bind(a);
var b = f(0, a.length);
document.cookie = b;