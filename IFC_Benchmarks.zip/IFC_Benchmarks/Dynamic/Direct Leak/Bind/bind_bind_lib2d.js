// Bind: Bind.Bind(Lib)
// Leak

document.cookie = 'abc';
var c = document.cookie;
var a = Function.prototype.bind.bind(String.prototype.substring, 'abc', 0, c.length);
var b = a();
document.cookie = b();
console.log(document.cookie);