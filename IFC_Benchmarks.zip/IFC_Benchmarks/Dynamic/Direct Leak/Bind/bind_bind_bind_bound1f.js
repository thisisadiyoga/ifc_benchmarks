// Bind: Bind.Bind(Bind, Bounded)
// NO Leak

function foo(x, y) {
	document.cookie = this.v;
	console.log(this.v + x + y);
}
document.cookie = "abc";
var b = foo.bind({v: 0}, document.cookie);
var f = Function.bind.bind(Function.bind, b, {v: document.cookie}, document.cookie, document.cookie);
var g = f();
var h = g();
h();