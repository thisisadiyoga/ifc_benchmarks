// Bind: Normal.Bind
// NO Leak

function foo(x, y) {
	document.cookie = this.v + x + y;
  console.log(this.v + " " + x + " " + y);
}
document.cookie = 'abc';
var e = document.cookie;
var a = foo.bind({v: 5});
var b = a.bind({v: e}, 1);
var c = b.bind({v: 3}, 2);
var d = {f: c};
d.f();