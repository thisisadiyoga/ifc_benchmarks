// Bind: Bind.Bind(Bind, Lib)
// Leak

document.cookie = 'abc';
var a = document.cookie;
var b = Function.prototype.bind.bind(Function.prototype.bind, String.prototype.substring, 'abc');
var c = b();
var d = c();
document.cookie = d(0, a.length);
console.log(document.cookie);