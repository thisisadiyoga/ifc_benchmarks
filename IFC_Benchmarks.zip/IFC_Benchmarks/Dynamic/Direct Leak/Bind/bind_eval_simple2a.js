// Bind: Eval.Bind
// Leak

var a = 'var b = document.cookie; document.cookie = b; console.log(b);';
var f = eval.bind({});
f(a);