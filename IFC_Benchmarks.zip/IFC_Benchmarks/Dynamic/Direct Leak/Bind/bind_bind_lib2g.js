// Bind: Bind.Bind(Lib)
// Leak

document.cookie = 'abc';
var c = document.cookie;
var a = Function.prototype.bind.bind(String.prototype.substring, 'abc');
var b = a(0);
document.cookie = b(c.length);
console.log(document.cookie);