// Bind: Lib.Bind
// Leak

var a = document.cookie;
var f = String.prototype.substring.bind(a, 0);
var b = f();
document.cookie = b;