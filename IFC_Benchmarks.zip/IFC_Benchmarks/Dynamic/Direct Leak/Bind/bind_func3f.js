// Bind: Normal.Bind
// NO Leak

function foo(x, y) {
	document.cookie = x + y;
  console.log(this.v + " " + x + " " + y);
}
document.cookie = 'abc';
var d = document.cookie;
var a = foo.bind({v: 0}, 1);
var b = a.bind({v: d}, 2);
var c = b.bind({v: d}, d);
c();