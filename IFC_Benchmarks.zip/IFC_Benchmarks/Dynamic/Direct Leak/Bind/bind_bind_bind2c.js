// Bind: Bind.Bind(Bind, Lib)
// Leak

document.cookie = 'abc';
var a = document.cookie;
var b = Function.prototype.bind.bind(Function.prototype.bind, String.prototype.substring, a, 0);
var c = b(1);
var d = c();
document.cookie = d();
console.log(document.cookie);