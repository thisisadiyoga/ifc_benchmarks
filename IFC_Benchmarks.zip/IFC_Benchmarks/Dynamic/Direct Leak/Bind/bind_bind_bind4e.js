// Bind: Bind.Bind(Bind, Lib)
// Leak

document.cookie = 'abc';
var a = document.cookie;
var b = Function.prototype.bind.bind(Function.prototype.bind, String.prototype.substring, 'abc');
var c = b(0);
var d = c(a.length);
document.cookie = d();
console.log(document.cookie);