// Bind: Normal.Bind
// NO Leak

function foo(x, y) {
	document.cookie = this.v;
  console.log(this.v + " " + x + " " + y);
}

var a = foo.bind({v: 5});
var b = a.bind({}, 1);
var c = b.bind({}, 2);
c();