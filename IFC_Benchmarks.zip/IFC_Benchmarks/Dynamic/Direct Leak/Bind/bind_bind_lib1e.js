// Bind: Bind.Bind(Lib)
// Leak

document.cookie = 'abc';
var a = Function.prototype.bind.bind(String.prototype.substring);
var b = a(document.cookie, 0);
document.cookie = b(1);
console.log(document.cookie);