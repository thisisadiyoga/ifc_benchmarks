// Bind: Bind.Bind(Bind, Bounded)
// Leak

function foo(x, y) {
	document.cookie = this.v;
	console.log(this.v + x + y);
}
document.cookie = "abc";
var b = foo.bind({v: document.cookie}, "A");
var f = Function.bind.bind(Function.bind, b, {v: 1}, "B", "C");
var g = f();
var h = g();
h();