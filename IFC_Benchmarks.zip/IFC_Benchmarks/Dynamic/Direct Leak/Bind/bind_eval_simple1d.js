// Bind: Eval.Bind
// Leak

a = document.cookie;	// force a to be global
var f = eval.bind({}, 'document.cookie = a;');
f();