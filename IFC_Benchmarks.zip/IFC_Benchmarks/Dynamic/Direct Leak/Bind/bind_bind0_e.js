// Bind: Bind.Bind(Lib)
// ERROR

var b = Function.prototype.bind.bind(alert);
var a = b({});
a();