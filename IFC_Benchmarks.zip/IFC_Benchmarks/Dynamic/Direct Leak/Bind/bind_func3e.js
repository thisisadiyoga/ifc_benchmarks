// Bind: Normal.Bind
// NO Leak

function foo(x, y) {
	document.cookie = x + y;
  console.log(this.v + " " + x + " " + y);
}
document.cookie = 'abc';
var d = document.cookie;
var a = foo.bind({v: 5}, 1);
var b = a.bind({v: 4}, 2);
var c = b.bind({v: 3}, d);
c();