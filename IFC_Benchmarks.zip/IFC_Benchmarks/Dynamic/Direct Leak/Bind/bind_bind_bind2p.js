// Bind: Bind.Bind(Bind, Lib)
// Leak

document.cookie = 'abc';
var a = document.cookie;
var b = Function.prototype.bind.bind(Function.prototype.bind, String.prototype.substring);
var c = b(a);
var d = c(0);
document.cookie = d(1);
console.log(document.cookie);