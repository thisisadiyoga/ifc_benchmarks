// Bind: Eval.Bind
// Leak

var f = eval.bind({});
f('var a = document.cookie; document.cookie = a;');