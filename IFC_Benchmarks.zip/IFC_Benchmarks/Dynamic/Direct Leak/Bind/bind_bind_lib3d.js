// Bind: Bind.Bind(Lib)
// NO Leak

document.cookie = 'abc';
var c = document.cookie;
var a = Function.prototype.bind.bind(String.prototype.substring, 'abc', 0, 1);
var b = a();
document.cookie = b(c.length);
console.log(document.cookie);