// Bind: Normal.Bind
// NO Leak

function foo(x, y) {
	document.cookie = this.v + x + y;
  console.log(this.v + " " + x + " " + y);
}
document.cookie = 'abc';
var e = document.cookie;
var a = foo.bind({v: 5});
var b = a.bind({v: 4}, 1);
var c = b.bind({v: e}, 2);
var d = {f: c};
d.f();