// Bind: Normal.Bind
// NO Leak

function foo(x) {
	document.cookie = x;
}

var a = document.cookie;
var f = foo.bind({}, 'non-secret');
f(a);