// Bind: Bind.Bind(Eval)
// NO Leak

var a = "document.cookie = 'abc'; var d = 'cde'; document.cookie = d; console.log(d);";
var b = Function.prototype.bind.bind(eval);
var c = b({}, a);
c();