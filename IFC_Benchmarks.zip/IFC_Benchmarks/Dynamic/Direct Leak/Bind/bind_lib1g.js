// Bind: Lib.Bind
// NO Leak

document.cookie = 'cde';
var a = document.cookie;
var f = String.prototype.substring.bind('a', 0, 1, a);
var b = f();
document.cookie = b;
console.log(document.cookie);