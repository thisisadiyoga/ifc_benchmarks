// Arrays
// Leak

document.cookie = 'abc';
var arr = [1, 2, 3, 4, document.cookie, 6, 7];
document.cookie = arr;
console.log(document.cookie);