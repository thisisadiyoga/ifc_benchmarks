// 2D Arrays
// Leak

document.cookie = 'abc';
var arr = [1, 2, 3, 4, ['a', 'b', 'c', document.cookie, 'e'], 6, 7];
document.cookie = arr[4][3];
console.log(document.cookie);