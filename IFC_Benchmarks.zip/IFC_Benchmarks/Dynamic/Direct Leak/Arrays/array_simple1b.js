// Arrays
// Leak

document.cookie = 'abc';
var arr = [1, 2, 3, 4, document.cookie, 6, 7];
for(var i in arr) {
	document.cookie = arr[i];
}
console.log(document.cookie);