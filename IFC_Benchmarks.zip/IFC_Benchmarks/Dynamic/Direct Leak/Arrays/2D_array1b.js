// 2D Arrays
// Leak

document.cookie = 'abc';
var arr = [1, 2, 3, 4, ['a', 'b', 'c', document.cookie, 'e'], 6, 7];
for(var i in arr) {
	document.cookie = arr[i];
}
console.log(document.cookie);