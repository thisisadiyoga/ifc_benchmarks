// Browser: Mozilla
// NO Leak

// _GD_val: {"1":false,"3":false,"4":false,"5":false,"6":false,"7":false,"8":false,"9":true,"11":true,"12":true,"13":false,"14":false,"15":true,"16":true,"17":false,"18":false,"19":false,"20":true,"21":true,"22":false}
// _GD_dep: {"1":{},"3":{},"4":{},"5":{},"6":{"3":1},"7":{"4":1,"5":1,"6":1},"8":{},"9":{"8":1},"11":{"9":1},"12":{"11":1},"13":{"4":1},"14":{},"15":{"12":1},"16":{"13":1,"14":1,"15":1},"17":{"17":1},"18":{},"19":{"19":1},"20":{"13":1},"21":{"20":1},"22":{"17":1,"18":1,"19":1}}

function safe() {
	return document.cookie;
}

if(true) {
	function safe() {
		return 'safe';
	}
}

document.cookie = 'abc';
var a = safe();
document.cookie = a;
console.log(document.cookie);