// Browser: All
// Leak

// _GD_val: {"1":false,"2":false,"3":false,"4":false,"5":false,"6":true,"7":false,"8":false,"9":false,"10":false,"11":false,"12":false,"13":false,"14":false,"15":true,"17":true,"18":true,"19":false,"20":false,"21":true,"22":true,"23":false,"24":false,"25":false,"26":true,"27":true,"28":true}
// _GD_dep: {"1":{"-1":1},"2":{"1":1},"3":{"5":1},"4":{"3":1},"5":{"4":1},"6":{"0":1,"1":1,"2":1},"7":{"-1":1},"8":{"5":1,"7":1},"9":{},"10":{"-1":1},"11":{"-1":1},"12":{"9":1},"13":{"10":1,"11":1,"12":1},"14":{"8":1},"15":{"6":1,"14":1},"17":{"15":1},"18":{"17":1},"19":{"10":1},"20":{"-1":1},"21":{"18":1},"22":{"19":1,"20":1,"21":1},"23":{"19":1},"24":{"-1":1},"25":{"21":1},"26":{"0":1,"1":1,"2":1},"27":{"26":1},"28":{"23":1,"24":1,"25":1}}

var safe = function() {
	return 'safe';
}

var select = false;

if(select) {
	var safe = function() {
		return document.cookie;
	}
}

document.cookie = 'abc';
var a = safe();
document.cookie = a;
console.log(document.cookie);