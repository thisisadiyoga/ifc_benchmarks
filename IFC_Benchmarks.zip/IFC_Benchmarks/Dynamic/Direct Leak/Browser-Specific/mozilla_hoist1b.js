// Browser: Mozilla
// Leak

function safe() {
	return 'safe';
}

var select = true;

if(select) {
	function safe() {
		return document.cookie;
	}
}

document.cookie = 'abc';
var a = safe();
document.cookie = a;
console.log(document.cookie);