// Browser: All
// Leak

var safe = function() {
	return document.cookie;
}

if(false) {
	var safe = function() {
		return 'safe';
	}
}

document.cookie = 'abc';
var a = safe();
document.cookie = a;
console.log(document.cookie);