// Browser: Mozilla
// Leak

// _GD_val: {"1":false,"2":false,"3":false,"4":true,"5":false,"6":false,"7":false,"8":false,"9":false,"10":false,"11":true,"13":true,"14":true,"15":false,"16":false,"17":true,"18":true,"19":false,"20":false,"21":false,"22":true,"23":true,"24":false}
// _GD_dep: {"1":{"3":1},"2":{"1":1},"3":{"2":1},"4":{"0":1,"1":1,"2":1},"5":{},"6":{"-1":1},"7":{"-1":1},"8":{"5":1},"9":{"6":1,"7":1,"8":1},"10":{"-1":1},"11":{"4":1,"10":1},"13":{"11":1},"14":{"13":1},"15":{"6":1},"16":{"-1":1},"17":{"14":1},"18":{"15":1,"16":1,"17":1},"19":{"-1":1},"20":{"-1":1},"21":{"-1":1},"22":{"0":1,"1":1,"2":1},"23":{"22":1},"24":{"19":1,"20":1,"21":1}}

function safe() {
	return 'safe';
}

var select = false;

if(select) {
	function safe() {
		return document.cookie;
	}
}

document.cookie = 'abc';
var a = safe();
document.cookie = a;
console.log(document.cookie);