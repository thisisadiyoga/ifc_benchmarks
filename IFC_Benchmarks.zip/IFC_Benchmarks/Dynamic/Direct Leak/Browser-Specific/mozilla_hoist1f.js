// Browser: Mozilla
// Leak

function safe() {
	return document.cookie;
}

var select = false;

if(select) {
	function safe() {
		return 'safe';
	}
}

document.cookie = 'abc';
var a = safe();
document.cookie = a;
console.log(document.cookie);