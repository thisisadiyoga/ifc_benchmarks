// Browser: All
// Leak

// _GD_val: {"1":false,"2":false,"3":false,"7":false,"8":false,"9":false,"10":false,"11":false,"12":false,"13":true,"15":true,"16":true,"17":false,"18":false,"19":true,"20":true,"21":false,"22":false,"23":false,"24":true,"25":true,"26":true}
// _GD_dep: {"1":{"-1":1},"2":{"1":1},"3":{"-1":1},"7":{},"8":{"-1":1},"9":{"-1":1},"10":{"7":1},"11":{"8":1,"9":1,"10":1},"12":{"2":1},"13":{"12":1},"15":{"13":1},"16":{"15":1},"17":{"8":1},"18":{"-1":1},"19":{"16":1},"20":{"17":1,"18":1,"19":1},"21":{"23":1},"22":{"-1":1},"23":{"25":1},"24":{"0":1,"1":1,"2":1},"25":{"24":1},"26":{"21":1,"22":1,"23":1}}

var safe = function() {
	return document.cookie;
}

var select = true;

if(select) {
	var safe = function() {
		return 'safe';
	}
}

document.cookie = 'abc';
var a = safe();
document.cookie = a;
console.log(document.cookie);