// Browser: Mozilla
// Leak

function safe() {
	return 'safe';
}

if(true) {
	function safe() {
		return document.cookie;
	}
}

document.cookie = 'abc';
var a = safe();
document.cookie = a;
console.log(document.cookie);