// Browser: All
// Leak

var safe = function() {
	return document.cookie;
}

var select = false;

if(select) {
	var safe = function() {
		return 'safe';
	}
}

document.cookie = 'abc';
var a = safe();
document.cookie = a;
console.log(document.cookie);