// Browser: All
// Leak

var safe = function() {
	return 'safe';
}

if(true) {
	var safe = function() {
		return document.cookie;
	}
}

document.cookie = 'abc';
var a = safe();
document.cookie = a;
console.log(document.cookie);