// Browser: Mozilla
// Leak

function safe() {
	return document.cookie;
}

if(false) {
	function safe() {
		return 'safe';
	}
}

document.cookie = 'abc';
var a = safe();
document.cookie = a;
console.log(document.cookie);