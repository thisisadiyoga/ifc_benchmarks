// Object: New Object
// Leak

document.cookie = 'abc';
function O() {
	this.x = document.cookie;
	this.y = 2;
}
var a = new O();
document.cookie = a;
console.log(a);