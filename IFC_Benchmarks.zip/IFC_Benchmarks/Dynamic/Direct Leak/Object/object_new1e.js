// Object: New Object
// Leak

document.cookie = 'abc';
function I() {
	this.y = document.cookie;
}
function O() {
	this.x = new I();
}
var a = new O();
document.cookie = a.x;
console.log(a.x);