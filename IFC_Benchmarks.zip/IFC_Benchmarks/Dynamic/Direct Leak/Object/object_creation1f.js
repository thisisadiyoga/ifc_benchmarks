// Object: Object Declaration
// Leak

document.cookie = 'abc';
var a = {x: {y: document.cookie}};
document.cookie = a.x.y;
console.log(a.x.y);