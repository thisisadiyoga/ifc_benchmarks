// Object: New Object
// Leak

document.cookie = 'abc';
function O() {
	this.x = document.cookie;
}
var a = new O();
document.cookie = a;
console.log(a);