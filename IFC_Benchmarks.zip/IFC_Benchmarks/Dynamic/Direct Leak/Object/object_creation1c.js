// Object: Object Declaration
// Leak

document.cookie = 'abc';
var a = {x: document.cookie, y: 2};
document.cookie = a;
console.log(a);