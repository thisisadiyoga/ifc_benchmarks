// Object: Object Declaration
// Leak

document.cookie = 'abc';
var a = {x: document.cookie};
document.cookie = a;
console.log(a);