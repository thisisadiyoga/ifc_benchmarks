// Object: Object Declaration
// Leak

document.cookie = 'abc';
var a = {x: document.cookie};
document.cookie = a.x;
console.log(a.x);