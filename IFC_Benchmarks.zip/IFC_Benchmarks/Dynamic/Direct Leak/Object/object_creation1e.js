// Object: Object Declaration
// Leak

document.cookie = 'abc';
var a = {x: {y: document.cookie}};
document.cookie = a.x;
console.log(a.x);