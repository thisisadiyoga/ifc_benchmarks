// Function Expressions
// NO Leak

function foo(x, y) {
	document.cookie = this.v;
	console.log(this.v + x + y);
}
document.cookie = "abc";
var x = {v: 0, foo: foo};
x.foo("A", "B");