// Function Expressions
// NO Leak

(function (x) {
	document.cookie = x;
})(0)