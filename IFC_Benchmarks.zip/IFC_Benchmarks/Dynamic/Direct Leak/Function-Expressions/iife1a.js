// Function Expressions
// Leak

(function (x) {
	document.cookie = x;
})(document.cookie)