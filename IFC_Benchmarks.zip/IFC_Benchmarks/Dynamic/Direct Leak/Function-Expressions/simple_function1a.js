// Function Expressions
// Leak

function foo(x, y) {
	document.cookie = this.v;
	console.log(this.v + x + y);
}
document.cookie = "abc";
var x = {v: document.cookie, foo: foo};
x.foo("A", "B");