// Prototype: Object Declaration
// Leak

document.cookie = 'abc';
var p = {x: 2};
var a = {x: {y: document.cookie}, __proto__: p};
document.cookie = a.x;
console.log(a.x);