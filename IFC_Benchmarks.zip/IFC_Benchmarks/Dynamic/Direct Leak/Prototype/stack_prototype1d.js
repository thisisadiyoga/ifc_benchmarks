// Prototype Stack: Object Declaration
// Leak

function push(stack, val) {
	return {v: val, __proto__: stack};
}
function pop(stack) {
	return stack.__proto__;
}
function create() {
	return {};
}

document.cookie = 'abc';
var s = create();
for(var i=0; i<10; i++) {
	if(i == 4) {
		s = push(s, document.cookie);
	} else {
		s = push(s, i);
	}
}
for(var i=5; i<10; i++) {
	if(i == 4) {
		s = pop(s);
	} else {
		s = pop(s);
	}
}
document.cookie = s.v;
console.log(document.cookie);
