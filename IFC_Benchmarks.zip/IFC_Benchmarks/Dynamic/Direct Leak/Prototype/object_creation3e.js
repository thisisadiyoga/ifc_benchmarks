// Prototype: Object Declaration
// NO Leak

document.cookie = 'abc';
var p = {x: {y: 2}};
var a = {x: {y: document.cookie}, __proto__: p};
var b = {y: 3, __proto__: p};
document.cookie = b.x;
console.log(b.x);