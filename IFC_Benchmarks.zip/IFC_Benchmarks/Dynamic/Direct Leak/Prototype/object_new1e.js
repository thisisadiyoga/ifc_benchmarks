// Prototype: New Object
// Leak

document.cookie = 'abc';
function I() {
	this.y = document.cookie;
}
I.prototype = {y: 2};
function O() {
	this.x = new I();
}
O.prototype = {x: 1};
var a = new O();
document.cookie = a.x;
console.log(a.x);