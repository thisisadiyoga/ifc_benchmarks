// Prototype: New Object
// NO Leak

document.cookie = 'abc';
var p = {x: document.cookie};
function O1() {
	this.x = 2;
}
function O2() {
	this.x = 3;
}
O1.prototype = p;
O2.prototype = p;
var a = new O1();
var b = new O2();
document.cookie = b;
console.log(b);