// Prototype: New Object
// NO Leak

document.cookie = 'abc';
function O() {
	this.x = 2;
}
O.prototype = {x: document.cookie, y: 3};
var a = new O();
document.cookie = a.y;
console.log(a.y);