// Prototype: Object Declaration
// NO Leak

document.cookie = 'abc';
var p = {x: document.cookie};
var q = {y: document.cookie};
var a = {x: {y: 2, __proto__: q} , __proto__: p};
document.cookie = a.x;
console.log(a.x);