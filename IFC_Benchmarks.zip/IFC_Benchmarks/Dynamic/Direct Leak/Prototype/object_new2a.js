// Prototype: New Object
// NO Leak

document.cookie = 'abc';
function O() {
	this.x = 2;
}
O.prototype = {x: document.cookie};
var a = new O();
document.cookie = a;
console.log(a);