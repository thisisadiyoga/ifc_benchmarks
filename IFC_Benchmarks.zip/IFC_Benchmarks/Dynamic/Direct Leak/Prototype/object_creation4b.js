// Prototype: Object Declaration
// NO Leak

document.cookie = 'abc';
var p = {x: document.cookie};
var a = {x: 2, __proto__: p};
var b = {x: 3, __proto__: p};
document.cookie = b.x;
console.log(b.x);