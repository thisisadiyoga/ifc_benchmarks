// Prototype: New Object
// Leak

document.cookie = 'abc';
function O() {
	this.x = document.cookie;
	this.y = 2;
}
O.prototype = {x: 1};
var a = new O();
document.cookie = a.x;
console.log(a.x);