// Prototype Stack: Object Declaration
// Leak

function push(stack, val) {
	return Object.create(stack, {v: {value: val, writable: true, configurable: true, enumerable: true}});
}
function pop(stack) {
	return Object.getPrototypeOf(stack);
}
function create() {
	return Object.create(null);
}

document.cookie = 'abc';
var s = create();
s = push(s, document.cookie);
document.cookie = s.v;
console.log(document.cookie);
