// Prototype: New Object
// NO Leak

document.cookie = 'abc';
var p = {x: 2};
function O1() {
	this.x = document.cookie;
}
function O2() {
	this.x = 2;
}
O1.prototype = p;
O2.prototype = p;
var a = new O1();
var b = new O2();
document.cookie = b.x;
console.log(b.x);