// Prototype: New Object
// NO Leak

document.cookie = 'abc';
function I() {
	this.y = 2;
}
I.prototype = {y: document.cookie};
function O() {
	this.x = new I();
}
O.prototype = {x: 1};
var a = new O();
document.cookie = a.x;
console.log(a.x);