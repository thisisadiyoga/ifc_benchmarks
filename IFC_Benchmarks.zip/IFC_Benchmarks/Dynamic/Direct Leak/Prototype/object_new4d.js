// Prototype: New Object
// NO Leak

document.cookie = 'abc';
var p = {x: document.cookie};
function O1() {
	this.x = 2;
	this.y = 2;
}
function O2() {
	this.x = 3;
	this.y = 4;
}
O1.prototype = p;
O2.prototype = p;
var a = new O1();
var b = new O2();
document.cookie = b.y;
console.log(b.y);