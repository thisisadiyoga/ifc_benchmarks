// Prototype Stack: Object Declaration
// Leak

function push(stack, val) {
	return {v: val, __proto__: stack};
}
function pop(stack) {
	return stack.__proto__;
}
function create() {
	return {};
}

document.cookie = 'abc';
var s = create();
s = push(s, document.cookie);
s = push(s, 1);
s = pop(s);
document.cookie = s.v;
console.log(document.cookie);
