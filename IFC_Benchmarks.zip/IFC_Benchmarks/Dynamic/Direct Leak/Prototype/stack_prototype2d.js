// Prototype Stack: Object Declaration
// Leak

function push(stack, val) {
	return Object.create(stack, {v: {value: val, writable: true, configurable: true, enumerable: true}});
}
function pop(stack) {
	return Object.getPrototypeOf(stack);
}
function create() {
	return Object.create(null);
}

document.cookie = 'abc';
var s = create();
for(var i=0; i<10; i++) {
	if(i == 4) {
		s = push(s, document.cookie);
	} else {
		s = push(s, i);
	}
}
for(var i=5; i<10; i++) {
	if(i == 4) {
		s = pop(s);
	} else {
		s = pop(s);
	}
}
document.cookie = s.v;
console.log(document.cookie);
