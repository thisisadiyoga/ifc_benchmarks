// Prototype: Object Declaration
// NO Leak

document.cookie = 'abc';
var p = {x: document.cookie};
var a = {x: 2, y:3, __proto__: p};
document.cookie = a.x;
console.log(a.x);