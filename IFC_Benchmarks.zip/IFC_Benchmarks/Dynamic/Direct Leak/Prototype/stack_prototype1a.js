// Prototype Stack: Object Declaration
// Leak

function push(stack, val) {
	return {v: val, __proto__: stack};
}
function pop(stack) {
	return stack.__proto__;
}
function create() {
	return {};
}

document.cookie = 'abc';
var s = create();
s = push(s, document.cookie);
document.cookie = s.v;
console.log(document.cookie);
