// Prototype: Object Declaration
// Leak

document.cookie = 'abc';
var p = {x: 2};
var a = {x: document.cookie, __proto__: p};
document.cookie = a;
console.log(a);