// Prototype: Object Declaration
// NO Leak

document.cookie = 'abc';
var p = {x: document.cookie};
var a = {x: 2, y: 2, __proto__: p};
var b = {x: 3, y: 3, __proto__: p};
document.cookie = b.y;
console.log(b.y);