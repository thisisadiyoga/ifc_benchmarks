// Native Function
// Leak

document.cookie = 'abc';
var a = document.cookie;
var b = String.prototype.substring.call(a, 0, 1);
document.cookie = b;
console.log(document.cookie);