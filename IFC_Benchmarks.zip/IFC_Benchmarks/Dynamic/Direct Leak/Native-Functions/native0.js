// Native Function
// NO Leak

console.log(console.log.length); 