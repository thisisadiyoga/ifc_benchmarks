// Native Function
// Leak

document.cookie = 'abc';
var a = document.cookie;
var b = a.substring(2);
document.cookie = b;
console.log(document.cookie);

