// Native Function
// NO Leak

document.cookie = 'abc';
var body = 'abcabcabc';
var a = document.cookie;
var b = body.split('abc', 2, a);
console.log(b.length);
for(var i=0; i<b.length; i++) {
	document.cookie = b[i];
}
console.log(document.cookie);

