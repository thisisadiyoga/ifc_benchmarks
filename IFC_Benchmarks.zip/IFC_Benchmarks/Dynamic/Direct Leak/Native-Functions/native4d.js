// Native Function
// Leak

document.cookie = 'abc';
var a = document.cookie;
var b = String.prototype.split.call(a, '');
console.log(b.length);
for(var i=0; i<b.length; i++) {
	document.cookie += b[i];
}
console.log(document.cookie);

