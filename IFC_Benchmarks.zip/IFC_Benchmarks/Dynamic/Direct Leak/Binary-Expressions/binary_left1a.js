// Binary Expression: Left
// Leak

document.cookie = 'abc';
var a = document.cookie;
var b = a + 1;
document.cookie = b;