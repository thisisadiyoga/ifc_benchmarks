// Binary Expression: Right
// Leak

document.cookie = 'abc';
var a = document.cookie;
var b = 'cba' + a;
document.cookie = b;