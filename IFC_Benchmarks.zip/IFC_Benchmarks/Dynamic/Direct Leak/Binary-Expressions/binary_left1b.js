// Binary Expression: Left
// Leak

document.cookie = 'abc';
var a = document.cookie;
var b = a + 'cba';
document.cookie = b;