// Key Overwrite
// NO Leak

document.cookie = 'abc';
var a = {x: document.cookie, x: 'cde'};
document.cookie = a.x;
console.log(document.cookie);