// Parameter Overwrite
// Leak

//var substr = String.prototype.substr;
document.cookie = 'abc';
var a = new String('cde');
a.substr = function(x, x) {
	return this + x;
}

var b = a.substr(0, document.cookie.length);
document.cookie = b;
//String.prototype.substr = substr;
console.log(document.cookie);