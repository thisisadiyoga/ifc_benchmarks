// Parameter Overwrite
// NO Leak

//var substr = String.prototype.substr;
document.cookie = 'abc';
var a = new String('cde');
a.substr = function(document, y) {
	return this + document.cookie;
}

var b = a.substr({cookie: 0}, 1);
document.cookie = b;
//String.prototype.substr = substr;
console.log(document.cookie);