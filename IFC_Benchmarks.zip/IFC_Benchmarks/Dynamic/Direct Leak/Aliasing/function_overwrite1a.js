// Function Overwrite
// Leak

var substr = String.prototype.substr;
String.prototype.substr = function(x, y) {
	return this + document.cookie;
}

document.cookie = 'abc';
var a = 'cde';
var b = a.substr(0, 1);
document.cookie = b;
String.prototype.substr = substr;
console.log(document.cookie);