// Variable Overwrite
// NO Leak

var substr = String.prototype.substr;
String.prototype.substr = function(x, y) {
	var document = {cookie: 0};
	return this + document.cookie;
}

document.cookie = 'abc';
var a = 'cde';
var b = a.substr({cookie: 0}, 1);
document.cookie = b;
String.prototype.substr = substr;
console.log(document.cookie);