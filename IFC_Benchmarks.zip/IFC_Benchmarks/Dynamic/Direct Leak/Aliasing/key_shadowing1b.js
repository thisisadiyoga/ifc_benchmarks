// Key Overwrite
// Leak

document.cookie = 'abc';
var a = {x: 'cde', x: document.cookie};
document.cookie = a.x;
console.log(document.cookie);