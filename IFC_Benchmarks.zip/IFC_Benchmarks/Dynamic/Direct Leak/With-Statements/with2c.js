// With Statement
// NO Leak

document.cookie = 'abc';
var d = document.cookie;
var cookie;
var obj = {};
with(obj) {
	cookie = 2;
}
