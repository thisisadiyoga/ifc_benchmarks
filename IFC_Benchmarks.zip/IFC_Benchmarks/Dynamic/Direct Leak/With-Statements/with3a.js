// With Statement
// Leak

document.cookie = 'abc';
var d = document.cookie;
var cookie;
var obj = document.cookie !== 'abc' ? {document: {}} : {cookie: 2};
with(obj) {
	document.cookie = cookie;
}