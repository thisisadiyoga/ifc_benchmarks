// With Statement
// NO Leak

document.cookie = 'abc';
var d = document.cookie;
var cookie;
var obj = {cookie: 0};
with(obj) {
	cookie = d;
}
document.cookie = cookie;