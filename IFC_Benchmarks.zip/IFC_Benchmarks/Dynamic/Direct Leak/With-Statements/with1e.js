// With Statement
// NO Leak

document.cookie = 'abc';
var d = document.cookie;
var cookie;
with({cookie: 3}) {
	cookie = d;
}