// With Statement
// Leak

document.cookie = 'abc';
var d = document.cookie;
var cookie;
with(document) {
	cookie = d;
}