// With Statement
// NO Leak

document.cookie = 'abc';
var d = document.cookie;
var cookie;
with({document: {}}) {
	document.cookie = d;
}