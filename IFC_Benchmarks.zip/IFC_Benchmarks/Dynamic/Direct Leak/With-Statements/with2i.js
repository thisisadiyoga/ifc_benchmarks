// With Statement
// Leak

document.cookie = 'abc';
var d = document.cookie;
var cookie;
var obj = {document: document};
with(obj) {
	with({}) {
		document.cookie = d;
	}
}