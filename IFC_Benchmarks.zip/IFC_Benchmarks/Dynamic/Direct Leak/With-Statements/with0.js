// With Statement
// Leak

with(document) {
	cookie = cookie;
}