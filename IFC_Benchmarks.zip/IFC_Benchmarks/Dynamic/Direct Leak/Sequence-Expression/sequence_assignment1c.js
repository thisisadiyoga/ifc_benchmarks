// Sequence Expression: Assignment
// Leak

document.cookie = 'abc';
var b = '';
var c = '';
var a = (b = document.cookie, c += 'def', b+c);
document.cookie = a;
console.log(a);