// Sequence Expression: Nested
// NO Leak

document.cookie = 'abc';
var a = (document.cookie, 1, 2, (document.cookie, 1, 2, 3));
document.cookie = a;
console.log(a);