// Sequence Expression: Nested
// Leak

document.cookie = 'abc';
var b = '', c = '';
var a = (b = 'def', b += (c = document.cookie, c += 'ghi', c));
document.cookie = a;
console.log(a);