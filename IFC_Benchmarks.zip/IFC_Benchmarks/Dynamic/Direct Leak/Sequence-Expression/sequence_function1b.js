// Sequence Expression: Function
// Leak

function foo(x) {
	return x;
}

document.cookie = 'abc';
var a = foo((1, document.cookie));
document.cookie = a;
console.log(a);