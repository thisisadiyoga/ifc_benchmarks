// Sequence Expression: Function
// NO Leak

function foo(x) {
	return x;
}

document.cookie = 'abc';
var a = foo((document.cookie, 1));
document.cookie = a;
console.log(a);