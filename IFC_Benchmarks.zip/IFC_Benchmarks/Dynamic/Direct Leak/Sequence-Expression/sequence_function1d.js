// Sequence Expression: Function
// NO Leak

function foo(x, y) {
	return x + y;
}

document.cookie = 'abc';
var a = foo((document.cookie, 1), 2);
document.cookie = a;
console.log(a);