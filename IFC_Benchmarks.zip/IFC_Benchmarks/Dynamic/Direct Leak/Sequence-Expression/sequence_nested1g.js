// Sequence Expression: Nested
// NO Leak

document.cookie = 'abc';
var b = '', c = '';
var a = (b = document.cookie, b = (c = 'def', c += 'ghi', c));
document.cookie = a;
console.log(a);