// Sequence Expression: Nested
// Leak

document.cookie = 'abc';
var b = '', c = '';
var a = (b = 'abc', b += (c = 'abc', c += 'abc', c + document.cookie));
document.cookie = a;
console.log(a);