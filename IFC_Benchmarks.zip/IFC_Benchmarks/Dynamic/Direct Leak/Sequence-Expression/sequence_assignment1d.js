// Sequence Expression: Assignment
// Leak

document.cookie = 'abc';
var b = '';
var c = '';
var a = (b = document.cookie, b += 'def', c += b + 'ghi', c);
document.cookie = a;
console.log(a);