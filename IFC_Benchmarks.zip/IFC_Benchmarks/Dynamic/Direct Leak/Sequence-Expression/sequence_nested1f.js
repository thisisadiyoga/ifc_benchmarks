// Sequence Expression: Nested
// Leak

document.cookie = 'abc';
var b = '', c = '';
var a = (b = 'abc', b += (c = 'def', c += 'ghi', c) + document.cookie);
document.cookie = a;
console.log(a);