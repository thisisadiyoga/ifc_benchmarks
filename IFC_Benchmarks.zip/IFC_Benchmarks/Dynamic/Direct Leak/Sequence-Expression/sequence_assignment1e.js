// Sequence Expression: Assignment
// NO Leak

document.cookie = 'abc';
var b = '';
var c = '';
var a = (b = document.cookie, c += 'def', b+c, 2);
document.cookie = a;
console.log(a);