// Sequence Expression: Nested
// Leak

document.cookie = 'abc';
var a = (0, 1, 2, (0, 1, 2, document.cookie));
document.cookie = a;
console.log(a);