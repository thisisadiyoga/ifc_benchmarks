// Sequence Expression: Simple
// NO Leak

document.cookie = 'abc';
var a = (document.cookie, 1, 2, 3);
document.cookie = a;
console.log(a);