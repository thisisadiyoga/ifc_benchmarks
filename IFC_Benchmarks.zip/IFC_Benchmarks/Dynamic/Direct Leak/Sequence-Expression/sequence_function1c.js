// Sequence Expression: Function
// Leak

function foo(x, y) {
	return x + y;
}

document.cookie = 'abc';
var a = foo((1, document.cookie), 2);
document.cookie = a;
console.log(a);