// Sequence Expression: Assignment
// Leak

document.cookie = 'abc';
var b = '';
var a = (b = document.cookie, b += 'def', b);
document.cookie = a;
console.log(a);