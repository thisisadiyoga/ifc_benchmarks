// Sequence Expression: Assignment
// NO Leak

document.cookie = 'abc';
var b = '';
var c = '';
var a = (b = document.cookie, b += 'def', c += b + 'ghi', c, 2);
document.cookie = a;
console.log(a);