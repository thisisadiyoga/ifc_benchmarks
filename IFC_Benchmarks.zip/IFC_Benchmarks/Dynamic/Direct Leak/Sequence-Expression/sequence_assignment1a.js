// Sequence Expression: Assignment
// NO Leak

document.cookie = 'abc';
var b = '';
var a = (b = document.cookie, b += 'def', b = 2, b);
document.cookie = a;
console.log(a);