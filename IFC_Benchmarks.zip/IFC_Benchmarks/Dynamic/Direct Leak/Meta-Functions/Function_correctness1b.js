// Function: Correctness
// NO Leak

var b = 2;
var f = new Function('b', 'return b;');
var a = f(b);
console.log(a);	// 2