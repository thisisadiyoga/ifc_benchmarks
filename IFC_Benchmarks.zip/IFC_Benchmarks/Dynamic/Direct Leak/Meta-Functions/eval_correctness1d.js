// Eval: Correctness
// NO Leak

(function () { var eval = myConsole.log; eval('foo'); })();