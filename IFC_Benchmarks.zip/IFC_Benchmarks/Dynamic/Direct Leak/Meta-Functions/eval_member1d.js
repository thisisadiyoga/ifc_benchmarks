// Meta: Eval
// Leak

a = document.cookie;
var c = 'document.cookie = a;';
document.cookie = 'abc';
function foo() {
	var a = "abc";
	eval.call({}, c);
}
foo();
console.log(document.cookie);