/*
	Meta Function: eval correctness
	- 0 leak
*/
function f(x) {
  "use strict";
  eval("var x = 2;");
  return x;
}

console.log(f(1));
console.log(x);	// error