// SetInterval: Correctness
// Leak

function print(x) {
	document.cookie = x;
	console.log(x);
}

a = 1;
f = print;
document.cookie = 'abc';
h = setInterval('f(document.cookie)', 1000);