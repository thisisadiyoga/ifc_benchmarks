// Meta: Eval
// Leak

a = document.cookie;
var c = 'document.cookie = a;';
var e = eval;
document.cookie = 'abc';
function foo() {
	var a = "abc";
	e(c);
}
foo();
console.log(document.cookie);