// Meta: Eval
// NO Leak

function foo(x) {
	"use strict";
	eval('var x = document.cookie;');
	return x;
}
document.cookie = 'abc';
document.cookie = foo('cde');
console.log(document.cookie);