// Meta: Eval
// ERROR

function foo(x) {
	var y = document.cookie;
	var e = eval;
	e('var x = y;');	// ReferenceError: y is not defined
	return x;
}
document.cookie = 'abc';
document.cookie = foo('cde');
console.log(document.cookie);