// SetInterval: Correctness
// NO Leak

function print(x) {
		console.log(x);
}

var x = 1;
h = setInterval(print(x), 1000);