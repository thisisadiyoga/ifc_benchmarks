// Eval: Correctness
// NO Leak

f = 1;
var a = (function(x){ var eval = x; var f = 2; return [x('f'), eval('f')] })(eval);
console.log(a);	// 1,2