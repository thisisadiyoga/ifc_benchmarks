// Eval: Correctness
// NO Leak

var a = (function (){ eval('var x = 10;'); return delete x; })();
console.log(a);	// true
// Caveat: the non eval cannot be tested in our system because we evaluate the given code using eval (should return false)