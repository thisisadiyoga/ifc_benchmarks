// Meta: Eval
// Leak

c = 'var a = document.cookie; document.cookie = a; console.log(document.cookie);';
document.cookie = 'abc';
eval.call({}, c);