// SetInterval: Correctness
// Leak

function print(x) {
		document.cookie = x;
		console.log(x);
}

var x = 1;
document.cookie = 'abc';
h = setInterval(print(document.cookie), 1000);