// SetTimeout: Correctness
// Leak

function foo(x) {
	a = x;
}
function bar() {
	document.cookie = a;
	console.log(a);
}

a = 1;
document.cookie = 'abc';
b = foo;
c = bar;
f = setTimeout(c, 3000);
g = setTimeout(b, 2000, document.cookie);
h = setTimeout(c, 1000);