// Eval: Correctness
// ERROR

with({'eval': console.log}) { eval('foo'); }	// foo