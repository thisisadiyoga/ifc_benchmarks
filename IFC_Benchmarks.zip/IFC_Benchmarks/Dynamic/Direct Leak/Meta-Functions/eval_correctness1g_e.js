// Eval: Correctness
// ERROR

f = eval;
(function (){ var q = 10; return f('q'); } )();	// ReferenceError: q is not defined