/*
	Meta Function: eval correctness
	- 0 leak
*/
function f(x) {
  var avel = eval;
  avel("var x = 2;");
  return x;
}
console.log(f(1));