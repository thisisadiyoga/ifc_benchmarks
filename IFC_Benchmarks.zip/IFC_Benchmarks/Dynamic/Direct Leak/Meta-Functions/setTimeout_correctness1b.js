// SetTimeout: Correctness
// Leak

function print(x) {
	return function() {
		document.cookie = x;
		console.log(x);
	}
}

var x = 1;
document.cookie = 'abc';
h = setTimeout(print(document.cookie), 1000);