// SetTimeout: Correctness
// NO Leak

function print(x) {
	console.log(x);
}

a = 1;
f = print;
h = setTimeout('f(a)', 1000);