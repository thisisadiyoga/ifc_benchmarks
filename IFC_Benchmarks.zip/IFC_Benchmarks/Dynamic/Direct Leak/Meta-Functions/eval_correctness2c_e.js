// Eval: Correctness
// ERROR

var a = (function(){ 'use strict'; eval('eval = console.log;'); })();
console.log(a);	// error