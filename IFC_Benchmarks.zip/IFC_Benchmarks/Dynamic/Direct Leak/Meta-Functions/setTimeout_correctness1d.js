// SetTimeout: Correctness
// NO Leak

function foo(x) {
	return function() {
		a = x;
	}
}
function bar() {
	return function() {
		document.cookie = a;
		console.log(a);
	}
}

a = 1;
document.cookie = 'abc';
b = foo;
c = bar;
g = setTimeout(b(document.cookie), 2000);
h = setTimeout(c(), 1000);