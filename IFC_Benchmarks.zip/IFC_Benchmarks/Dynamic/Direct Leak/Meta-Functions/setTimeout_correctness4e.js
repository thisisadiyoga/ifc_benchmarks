// SetTimeout: Correctness
// Leak

function foo(x) {
		a = x;
}
function bar() {
		document.cookie = a;
		console.log(a);
}

a = 1;
document.cookie = 'abc';
b = foo;
c = bar;
f = setTimeout(c(), 3000);								// Immediate Execution
g = setTimeout(b(document.cookie), 2000);	// Immediate Execution
h = setTimeout(c(), 1000);								// The cause of Leak