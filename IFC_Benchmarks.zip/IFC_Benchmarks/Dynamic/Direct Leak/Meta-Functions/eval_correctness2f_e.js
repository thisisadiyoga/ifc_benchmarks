// Eval: Correctness
// ERROR

with({'eval':console.log}) { (function(){ 'use strict'; return eval('eval'); })() } // eval
//console.log(a);	// error