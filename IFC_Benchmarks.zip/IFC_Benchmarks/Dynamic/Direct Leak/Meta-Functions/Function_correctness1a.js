// Function: Correctness
// NO Leak

var f = new Function('var x = 2; return x;');
var a = f();
console.log(a);	// 2