// Meta: Eval
// NO Leak

var c = 'var a = document.cookie; document.cookie = a;';
var e = eval;
document.cookie = 'abc';
function foo() {
	var c = 'var a = "abc"; document.cookie = a;';
	e(c);
}
foo();
console.log(document.cookie);