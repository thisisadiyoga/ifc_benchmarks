// Meta: Eval
// NO Leak

function foo(x) {
	var e = eval;
	e('var x = document.cookie;');
	return x;
}
document.cookie = 'abc';
document.cookie = foo('cde');
console.log(document.cookie);