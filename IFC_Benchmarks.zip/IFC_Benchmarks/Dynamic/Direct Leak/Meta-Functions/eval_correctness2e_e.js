// Eval: Correctness
// ERROR

var a = (function(){ var eval = console.log; (function(){ "use strict"; return eval('eval'); })();})();	// eval
//console.log(a);	// error