// Function: Correctness
// Leak

document.cookie = 'abc';
var f = new Function('var x = document.cookie; return x;');
var a = f();
document.cookie = a;
console.log(a);	// abc