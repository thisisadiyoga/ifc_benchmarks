// Function: Correctness
// Leak

document.cookie = 'abcde';
var b = 'var c = document.cookie; document.cookie = c; console.log(c);';
var f = new Function('b', 'eval(b);');
var a = f(b);