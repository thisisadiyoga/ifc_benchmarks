// Meta: Eval
// NO Leak

a = "abc";
var c = 'document.cookie = a;';
var e = eval;
document.cookie = 'abc';
function foo() {
	var a = document.cookie;
	e(c);
}
foo();
console.log(document.cookie);