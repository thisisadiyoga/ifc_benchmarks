// Meta: Eval
// Leak

var c = 'var a = document.cookie; document.cookie = a;';
var e = eval;
document.cookie = 'abc';
e(c);