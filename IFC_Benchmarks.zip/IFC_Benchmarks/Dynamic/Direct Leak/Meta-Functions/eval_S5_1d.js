/*
	Meta Function: eval correctness
	- 0 leak
*/
function f(x) {
  var y = 2;
  eval("var x = y;");
  return x;
}
console.log(f(1));