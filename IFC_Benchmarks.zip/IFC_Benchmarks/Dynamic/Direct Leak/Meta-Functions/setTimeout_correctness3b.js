// SetTimeout: Correctness
// Leak

function print(x) {
	document.cookie = x;
	console.log(x);
}

a = 1;
f = print;
document.cookie = 'abc';
h = setTimeout('f(document.cookie)', 1000);