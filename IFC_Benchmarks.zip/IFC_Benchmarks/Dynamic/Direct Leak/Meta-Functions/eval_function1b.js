// Meta: Eval
// Leak

function foo(x) {
	var y = document.cookie;
	eval('var x = y;');
	return x;
}
document.cookie = 'abc';
document.cookie = foo('cde');
console.log(document.cookie);