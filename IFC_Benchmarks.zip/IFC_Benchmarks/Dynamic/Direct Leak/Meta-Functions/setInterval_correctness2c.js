// SetInterval: Correctness
// Leak

function foo(x) {
	a = x;
}
function bar() {
	document.cookie = a;
	console.log(a);
}

a = 1;
document.cookie = 'abc';
b = foo;
c = bar;
g = setInterval(b, 1000, document.cookie);
h = setInterval(c, 1000);