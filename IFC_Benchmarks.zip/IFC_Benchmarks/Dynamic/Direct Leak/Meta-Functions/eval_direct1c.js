// Meta: Eval
// Leak

a = "abc";
var c = 'document.cookie = a;';
document.cookie = 'abc';
function foo() {
	var a = document.cookie;
	eval(c);
}
foo();
console.log(document.cookie);