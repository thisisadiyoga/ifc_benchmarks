// Meta: Eval
// Leak

var c = 'var a = document.cookie; document.cookie = a;';
document.cookie = 'abc';
eval(c);