// SetInterval: Correctness
// Leak

function foo(x) {
		a = x;
}
function bar() {
		document.cookie = a;
		console.log(a);
}

a = 1;
document.cookie = 'abc';
b = foo;
c = bar;
f = setInterval(c(), 3000);									// Executed immediately
g = setInterval(b(document.cookie), 2000);	// Executed immediately
h = setInterval(c(), 1000);									// Leak