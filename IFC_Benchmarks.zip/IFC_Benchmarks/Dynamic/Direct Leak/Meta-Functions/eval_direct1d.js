// Meta: Eval
// NO Leak

a = document.cookie;
var c = 'document.cookie = a;';
document.cookie = 'abc';
function foo() {
	var a = "abc";
	eval(c);
}
foo();
console.log(document.cookie);