// Eval: Correctness
// NO Leak

var x = 1;
var a = (function () { eval('var x = 2;'); return x; })();
console.log(a);	// 2