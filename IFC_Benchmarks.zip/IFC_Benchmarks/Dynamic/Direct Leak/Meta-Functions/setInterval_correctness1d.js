// SetInterval: Correctness
// Leak

function foo(x) {
	return function() {
		a = x;
	}
}
function bar() {
	return function() {
		document.cookie = a;
		console.log(a);
	}
}

a = 1;
document.cookie = 'abc';
b = foo;
c = bar;
g = setInterval(b(document.cookie), 2000);
h = setInterval(c(), 1000);