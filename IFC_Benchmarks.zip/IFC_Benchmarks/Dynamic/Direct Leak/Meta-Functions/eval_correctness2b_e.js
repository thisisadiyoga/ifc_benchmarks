// Eval: Correctness
// ERROR

var a = (function(){ 'use strict'; eval = console.log; })();
console.log(a);	// error