// Meta: Eval
// Leak

function foo(x) {
	eval('var x = document.cookie');
	return x;
}
document.cookie = 'abc';
document.cookie = foo('cde');
console.log(document.cookie);