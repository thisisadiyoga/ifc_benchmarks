// Eval: Correctness
// ERROR

eval = console.log;
var a = (function(){ 'use strict'; return eval('eval'); })();	// eval
//console.log(a);