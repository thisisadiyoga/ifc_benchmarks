// Eval: Correctness
// NO Leak

f = eval;
console.log(f('f') === eval);	// true