/*
	Meta Function: eval correctness
	- 0 leak
*/
function f(x) {
  eval("var x = 2;");
  return x;
}
console.log(f(1));