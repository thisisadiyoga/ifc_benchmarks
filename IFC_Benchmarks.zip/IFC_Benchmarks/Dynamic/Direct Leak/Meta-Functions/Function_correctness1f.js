// Function: Correctness
// Leak

document.cookie = 'abc';
var f = new Function('b', 'return b;');
var a = f(document.cookie);
document.cookie = a;
console.log(a);	// abc