// SetTimeout: Correctness
// Leak

function foo(x) {
	a = x;
}
function bar() {
	document.cookie = a;
	console.log(a);
}

a = 1;
document.cookie = 'abc';
b = foo;
c = bar;
g = setTimeout('b(document.cookie)', 1000);
h = setTimeout('c()', 1000);