// Meta: Eval
// NO Leak

var c = 'var a = document.cookie; document.cookie = a;';
document.cookie = 'abc';
function foo() {
	var c = 'var a = "abc"; document.cookie = a;';
	eval(c);
}
foo();
console.log(document.cookie);