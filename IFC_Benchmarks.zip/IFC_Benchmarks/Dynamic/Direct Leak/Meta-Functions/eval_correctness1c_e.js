// Eval: Correctness
// ERROR

eval = console.log;
eval('foo');	// foo