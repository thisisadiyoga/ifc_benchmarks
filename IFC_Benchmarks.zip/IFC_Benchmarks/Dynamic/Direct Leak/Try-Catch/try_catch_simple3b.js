// Try Catch
// Leak

var a = '';
document.cookie = 'abc';

function foo(x) {
	a = document.cookie;
	try {
		x.y;
	} catch(e) {
		a = 2;
	}
}

foo({});

document.cookie = a;
console.log(a);