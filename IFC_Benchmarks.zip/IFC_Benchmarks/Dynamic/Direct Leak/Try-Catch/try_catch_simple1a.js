// Try Catch
// Leak

var a = '';
document.cookie = 'abc';

function foo(x) {
	a = document.cookie;
	x.y;
	a = 2;
}

try {
	foo();
} catch(e) {
	
}

document.cookie = a;
console.log(a);