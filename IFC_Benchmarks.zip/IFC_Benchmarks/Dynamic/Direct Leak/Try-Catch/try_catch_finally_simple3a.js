// Try Catch Finally
// NO Leak

var a = '';
document.cookie = 'abc';

function foo(x) {
	a = document.cookie;
	try {
		x.y;
	} catch(e) { a = 2; } finally { a = 3; }
}

foo();

document.cookie = a;
console.log(a);