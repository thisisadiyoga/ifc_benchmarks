// Try Catch Finally
// NO Leak

var a = '';
document.cookie = 'abc';

function foo(x) {
	a = document.cookie;
	x.y;
	a = 2;
}

try {
	foo();
} catch(e) {
	
} finally {
	a = 2;
}

document.cookie = a;
console.log(a);