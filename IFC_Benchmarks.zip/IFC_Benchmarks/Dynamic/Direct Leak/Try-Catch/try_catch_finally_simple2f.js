// Try Catch Finally
// NO Leak

var a = '';
document.cookie = 'abc';

function foo(x) {
	a = document.cookie;
	try {
		x.y;
	} catch(e) {} finally { a = document.cookie; }
	a = 2;
}

foo({y: 1});

document.cookie = a;
console.log(a);