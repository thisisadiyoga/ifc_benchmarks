// Try Catch Finally
// Leak

var a = '';
document.cookie = 'abc';

function foo(x) {
	a = document.cookie;
	x.y;
	a = 2;
}

try {
	foo({y: 1});
} catch(e) {
	
} finally {
	a = document.cookie;
}

document.cookie = a;
console.log(a);