// Try Catch
// NO Leak

var a = '';
document.cookie = 'abc';

function foo(x) {
	a = document.cookie;
	x.y;
	a = 2;
}

try {
	foo({y: 1});
} catch(e) {
	
}

document.cookie = a;
console.log(a);