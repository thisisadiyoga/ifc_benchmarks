// Getter & Setter: Correctness
// Leak

var o = {
  get x()  { return this._x + 'ghi'; },
  set x(v) { this._x = v + 'def'; }
};
o.x = document.cookie;
document.cookie = o._x;	// - Flow
console.log(document.cookie);	// undefineddef
document.cookie = o.x;	// - Flow
console.log(document.cookie);	// undefineddefghi