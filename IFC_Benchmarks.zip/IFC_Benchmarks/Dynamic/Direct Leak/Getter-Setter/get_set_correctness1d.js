// Getter & Setter: Correctness
// Leak

document.cookie = 'abc';
var c = 'ghi';
var parent = {
  get x() { return this._x + c; },
  set x(v) { this._x = v + 'def'; }
};
var child = Object.create(parent);
child.x  = 5;
child._x = document.cookie;
document.cookie = parent._x;	
console.log(parent._x);				// ''
document.cookie = child._x;		// - Flow
console.log(child._x);				// abc
document.cookie = parent.x;		
console.log(parent.x);				// undefinedghi
document.cookie = child.x;		// - Flow
console.log(child.x);					// abcghi