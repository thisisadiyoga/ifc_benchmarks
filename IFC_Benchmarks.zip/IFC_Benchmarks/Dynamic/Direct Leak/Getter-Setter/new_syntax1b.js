// Getter & Setter: New Syntax
// Leak

function Foo(val) {
	this._value = val;
}
Foo.prototype = {
	get value() {
		return this._value;
	},
	set value(val) {
		this._value = val;
	}
};

var a = new Foo(document.cookie);
document.cookie = a.value;
console.log(document.cookie);