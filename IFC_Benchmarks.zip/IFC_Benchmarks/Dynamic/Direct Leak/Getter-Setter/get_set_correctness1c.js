// Getter & Setter: Correctness
// NO Leak

document.cookie = 'abc';
var c = 'ghi';
var parent = {
  get x() { return this._x + c; },
  set x(v) { this._x = v + 'def'; }
};
var child = Object.create(parent);
child._x = document.cookie;
child.x  = 5;
document.cookie = parent._x;	
console.log(parent._x);				// ''
document.cookie = child._x;		
console.log(child._x);				// 5def
document.cookie = parent.x;		
console.log(parent.x);				// undefinedghi
document.cookie = child.x;		
console.log(child.x);					// 5defghi