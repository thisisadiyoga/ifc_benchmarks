// Getter & Setter: Correctness
// Leak

document.cookie = 'abc';
var foo = document.cookie;
var o = {set x(v) { foo = v; }};
document.cookie = foo;	// - Flow
console.log(document.cookie);	// abc

o.x = 'def';
document.cookie = foo;
console.log(document.cookie);	// def
document.cookie = o.x;
console.log(document.cookie);	// undefined