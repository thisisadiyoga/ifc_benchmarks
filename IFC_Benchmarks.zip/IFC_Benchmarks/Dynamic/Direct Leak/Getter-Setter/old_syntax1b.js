// Getter & Setter: Old Syntax
// Leak

function Foo(val) {
	var value = val;
	this.__defineGetter__("value", function() { return value; });
	this.__defineSetter__("value", function(val) { value = val; });
}

var a = new Foo(document.cookie);
document.cookie = a.value;
console.log(document.cookie);