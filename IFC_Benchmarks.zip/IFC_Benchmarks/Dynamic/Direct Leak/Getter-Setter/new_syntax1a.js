// Getter & Setter: New Syntax
// NO Leak

function Foo(val) {
	this._value = val;
}
Foo.prototype = {
	get value() {
		return this._value;
	},
	set value(val) {
		this._value = val;
	}
};

var a = new Foo(0);
console.log(a.value);