// Getter & Setter: Correctness
// Leak

document.cookie = 'abc';
var c = document.cookie;
var parent = {
  get x() { return this._x + 1; },
  set x(v) { this._x = v + c; }
};
var child = Object.create(parent);
child.x = 5;
document.cookie = parent._x;
console.log(parent._x);				// ''
document.cookie = child._x;		// - Flow
console.log(child._x);				// 5abc
document.cookie = parent.x;
console.log(parent.x);				// NaN
document.cookie = child.x;		// - Flow
console.log(child.x);					// 5abc1