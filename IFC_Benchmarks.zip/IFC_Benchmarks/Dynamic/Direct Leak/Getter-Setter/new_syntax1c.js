// Getter & Setter: New Syntax
// Leak

function Foo(val) {
	this._value = val;
}
Foo.prototype = {
	get value() {
		return this._value;
	},
	set value(val) {
		this._value = val;
	}
};

document.cookie = 'abc';
var a = new Foo(0);
a.value = document.cookie;
document.cookie = a.value;
console.log(document.cookie);