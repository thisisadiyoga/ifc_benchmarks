// Getter & Setter: Old Syntax
// Leak

function Foo(val) {
	this._value = val;
	this.__defineGetter__("value", function() { return this._value; });
	this.__defineSetter__("value", function(val) { this._value = val; });
}

document.cookie = 'abc';
var a = new Foo(0);
a.value = document.cookie;
document.cookie = a.value;
console.log(document.cookie);