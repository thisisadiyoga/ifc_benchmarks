// Getter & Setter: Correctness
// NO Leak

var o = {
	_x: 'abc',
  get x()  { return this._x + 'ghi'; },
  set x(v) { this._x = v + 'def'; }
};
o.x = 'jkl';
document.cookie = o._x;	
console.log(document.cookie);	// jkldef
document.cookie = o.x;	
console.log(document.cookie);	// jkldefghi