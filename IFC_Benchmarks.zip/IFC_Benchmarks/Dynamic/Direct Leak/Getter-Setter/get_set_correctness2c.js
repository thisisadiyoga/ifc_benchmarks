// Getter & Setter: Correctness
// Leak

document.cookie = 'abc';
var t = 'cde';
var o = {get x() { t+=document.cookie; return 22; }};
document.cookie = t;
console.log(document.cookie);	// cde
document.cookie = o.x;
console.log(document.cookie);	// 22
document.cookie = t;	// - Flow
console.log(document.cookie);	// cdecde
document.cookie = o.x;
console.log(document.cookie);	// 22
document.cookie = t;	// - Flow
console.log(document.cookie);	// cdecdecdecde