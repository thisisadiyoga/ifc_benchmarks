// Getter & Setter: Old Syntax
// NO Leak

function Foo(val) {
	var value = val;
	this.__defineGetter__("value", function() { return value; });
	this.__defineSetter__("value", function(val) { value = val; });
}

var a = new Foo(0);
console.log(a.value);