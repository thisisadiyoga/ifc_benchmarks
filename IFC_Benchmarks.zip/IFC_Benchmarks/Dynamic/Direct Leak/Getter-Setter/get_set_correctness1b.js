// Getter & Setter: Correctness
// Leak

document.cookie = 'abc';
var c = document.cookie;
var parent = {
  get x() { return this._x + c; },
  set x(v) { this._x = v + 'def'; }
};
var child = Object.create(parent);
child.x = 5;
document.cookie = parent._x;	
console.log(parent._x);				// ''
document.cookie = child._x;		
console.log(child._x);				// 5def
document.cookie = parent.x;		// - Flow
console.log(parent.x);				// undefinedabc
document.cookie = child.x;		// - Flow
console.log(child.x);					// 5defabc