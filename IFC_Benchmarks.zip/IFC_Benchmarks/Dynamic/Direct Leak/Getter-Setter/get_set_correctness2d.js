// Getter & Setter: Correctness
// Leak

document.cookie = 'abc';
var t = document.cookie;
var o = {get x() { t+='def'; return 22; }};
document.cookie = t;	// - Flow
console.log(document.cookie);	// abc
document.cookie = o.x;
console.log(document.cookie);	// 22
document.cookie = t;	// - Flow
console.log(document.cookie);	// abcdef
document.cookie = o.x;
console.log(document.cookie);	// 22
document.cookie = t;	// - Flow
console.log(document.cookie);	// abcdefdef