// Getter & Setter: Correctness
// Leak

document.cookie = 'abc';
var t = document.cookie;
var o = {get x() { t+='def'; return 22; }};
document.cookie = t;	// - Flow
console.log(document.cookie);	// abc
o.x;
document.cookie = t;	// - Flow
console.log(document.cookie);	// abcdef
o.x;
document.cookie = t;	// - Flow
console.log(document.cookie);	// abcdefdef