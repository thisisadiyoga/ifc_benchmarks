// Getter & Setter: Correctness
// Leak

document.cookie = 'abc';
var t = 'cde';
var o = {get x() { t+=document.cookie; return 22; }};
document.cookie = t;
console.log(document.cookie);	// cde
o.x;
document.cookie = t;	// - Flow
console.log(document.cookie);	// cdecde
o.x;
document.cookie = t;	// - Flow
console.log(document.cookie);	// cdecdecdecde