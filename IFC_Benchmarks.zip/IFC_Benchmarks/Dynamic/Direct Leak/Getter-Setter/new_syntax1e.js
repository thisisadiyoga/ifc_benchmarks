// Getter & Setter: New Syntax
// Leak

function Foo(val) {
	this._value = val;
	this._foo = function() {
		this._value = document.cookie;
	}
}
Foo.prototype = {
	get value() {
		return this._foo;
	},
	set value(val) {
		this._value = val;
	}
};

document.cookie = 'abc';
var a = new Foo(0);
a.value();
document.cookie = a._value;
console.log(document.cookie);