// Getter & Setter: Correctness
// Leak

document.cookie = 'abc';
var foo = 'def';
var o = {set x(v) { foo = v; }};
document.cookie = foo;
console.log(document.cookie);	// def

o.x = document.cookie;
document.cookie = foo;	// - Flow
console.log(document.cookie);	// def
document.cookie = o.x;
console.log(document.cookie);	// undefined